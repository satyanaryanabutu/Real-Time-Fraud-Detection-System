import java.time.LocalDateTime;

/** Run this class to see the DSA components working together. */
public class DSADemo {
    public static void main(String[] args) {
        TransactionHashMap transactionMap = new TransactionHashMap();
        TransactionQueue processingQueue = new TransactionQueue();
        TransactionFrequency frequencyCounter = new TransactionFrequency();
        SlidingWindow slidingWindow = new SlidingWindow(10);

        LocalDateTime now = LocalDateTime.now();

        Transaction t1 = new Transaction("TXN101", "ACC101", 1200.00, "Jalandhar", now.minusMinutes(4));
        Transaction t2 = new Transaction("TXN102", "ACC101", 8500.00, "Delhi", now.minusMinutes(2));
        Transaction t3 = new Transaction("TXN103", "ACC101", 3000.00, "Mumbai", now);

        Transaction[] sampleTransactions = { t1, t2, t3 };

        for (Transaction transaction : sampleTransactions) {
            transactionMap.addTransaction(transaction);
            processingQueue.add(transaction);
            frequencyCounter.record(transaction.getAccountId());
            slidingWindow.addTransactionTime(transaction.getTimestamp());
        }

        System.out.println("=== HashMap: transactions by account ===");
        transactionMap.printAllAccounts();
        System.out.println("ACC101 transaction count: "
                + transactionMap.getTransactionCount("ACC101"));

        System.out.println("\n=== Queue: processing in arrival order ===");
        while (!processingQueue.isEmpty()) {
            System.out.println("Processing " + processingQueue.processNext());
        }

        System.out.println("\n=== Frequency Counter ===");
        frequencyCounter.printFrequencies();

        System.out.println("\n=== Sliding Window (last 10 minutes) ===");
        int recentCount = slidingWindow.getCount(now);
        System.out.println("Recent transactions: " + recentCount);
        if (slidingWindow.isHighFrequency(now, 3)) {
            System.out.println("FRAUD ALERT: High transaction frequency detected.");
        } else {
            System.out.println("No high-frequency alert.");
        }
    }
}
