import java.util.ArrayDeque;
import java.util.Queue;

/**
 * DSA: FIFO queue for processing transactions in arrival order.
 * Enqueue and dequeue are O(1) amortized with ArrayDeque.
 */
public class TransactionQueue {
    private final Queue<Transaction> queue = new ArrayDeque<>();

    public void add(Transaction transaction) {
        queue.offer(transaction);
    }

    public Transaction processNext() {
        return queue.poll(); // returns null when the queue is empty
    }

    public Transaction peekNext() {
        return queue.peek();
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }

    public int size() {
        return queue.size();
    }
}
