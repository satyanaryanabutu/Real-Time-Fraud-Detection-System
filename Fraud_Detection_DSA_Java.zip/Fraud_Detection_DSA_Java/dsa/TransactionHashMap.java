import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * DSA: HashMap stores transactions against each account ID.
 * Average lookup and insertion are O(1); retrieving an account's full list is O(k).
 */
public class TransactionHashMap {
    private final Map<String, List<Transaction>> accountTransactions = new HashMap<>();

    public void addTransaction(Transaction transaction) {
        accountTransactions
                .computeIfAbsent(transaction.getAccountId(), key -> new ArrayList<>())
                .add(transaction);
    }

    public List<Transaction> getTransactions(String accountId) {
        List<Transaction> result = accountTransactions.get(accountId);
        return result == null ? new ArrayList<>() : new ArrayList<>(result);
    }

    public int getTransactionCount(String accountId) {
        List<Transaction> result = accountTransactions.get(accountId);
        return result == null ? 0 : result.size();
    }

    public boolean hasAccount(String accountId) {
        return accountTransactions.containsKey(accountId);
    }

    public void printAllAccounts() {
        if (accountTransactions.isEmpty()) {
            System.out.println("No transactions stored.");
            return;
        }
        for (Map.Entry<String, List<Transaction>> entry : accountTransactions.entrySet()) {
            System.out.println(entry.getKey() + " -> " + entry.getValue().size() + " transaction(s)");
        }
    }
}
