import java.util.HashMap;
import java.util.Map;

/**
 * DSA: HashMap frequency counter for transactions per account.
 * Update and lookup are O(1) on average.
 */
public class TransactionFrequency {
    private final Map<String, Integer> frequency = new HashMap<>();

    public void record(String accountId) {
        frequency.put(accountId, frequency.getOrDefault(accountId, 0) + 1);
    }

    public int getFrequency(String accountId) {
        return frequency.getOrDefault(accountId, 0);
    }

    public void printFrequencies() {
        if (frequency.isEmpty()) {
            System.out.println("No transaction frequencies recorded.");
            return;
        }
        for (Map.Entry<String, Integer> entry : frequency.entrySet()) {
            System.out.println(entry.getKey() + " -> " + entry.getValue());
        }
    }
}
