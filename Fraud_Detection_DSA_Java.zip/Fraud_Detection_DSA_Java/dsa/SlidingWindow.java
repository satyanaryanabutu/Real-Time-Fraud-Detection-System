import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayDeque;
import java.util.Deque;

/**
 * DSA: Sliding window implemented with an ArrayDeque.
 * Keeps timestamps from the latest configured number of minutes.
 */
public class SlidingWindow {
    private final int windowMinutes;
    private final Deque<LocalDateTime> timestamps = new ArrayDeque<>();

    public SlidingWindow(int windowMinutes) {
        if (windowMinutes <= 0) {
            throw new IllegalArgumentException("Window must be greater than zero.");
        }
        this.windowMinutes = windowMinutes;
    }

    public void addTransactionTime(LocalDateTime time) {
        removeExpired(time);
        timestamps.addLast(time);
    }

    private void removeExpired(LocalDateTime currentTime) {
        while (!timestamps.isEmpty()
                && Duration.between(timestamps.peekFirst(), currentTime).toMinutes() >= windowMinutes) {
            timestamps.removeFirst();
        }
    }

    public int getCount(LocalDateTime currentTime) {
        removeExpired(currentTime);
        return timestamps.size();
    }

    public boolean isHighFrequency(LocalDateTime currentTime, int limit) {
        if (limit <= 0) {
            throw new IllegalArgumentException("Limit must be greater than zero.");
        }
        return getCount(currentTime) >= limit;
    }
}
