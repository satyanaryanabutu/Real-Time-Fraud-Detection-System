# Java DSA Files for Fraud Detection Project

These Java files demonstrate DSA techniques that can support a fraud-detection workflow.

## Files
- `Transaction.java` — transaction data model.
- `TransactionHashMap.java` — groups transactions by account ID using a HashMap.
- `SlidingWindow.java` — tracks transactions within a rolling time window using an ArrayDeque.
- `TransactionQueue.java` — processes transactions in FIFO order.
- `TransactionFrequency.java` — counts transactions for each account using a HashMap.
- `DSADemo.java` — sample program that runs all the above classes.

## Run
Open a terminal inside this `dsa` folder and run:

```bash
javac *.java
java DSADemo
```

Requires JDK 8 or newer.

## Complexity summary
| Structure / operation | Average time |
|---|---:|
| HashMap account insert / lookup | O(1) |
| Queue offer / poll using ArrayDeque | O(1) amortized |
| Sliding-window add / expiry | O(1) amortized per timestamp |
| Frequency counter update / lookup | O(1) average |

This is an educational DSA module. It is separate from the Python ML notebook unless you connect the Java code to that model yourself.
