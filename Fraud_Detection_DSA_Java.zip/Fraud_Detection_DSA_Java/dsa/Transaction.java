import java.time.LocalDateTime;

/** Represents one transaction in the educational fraud-detection demo. */
public class Transaction {
    private final String transactionId;
    private final String accountId;
    private final double amount;
    private final String location;
    private final LocalDateTime timestamp;

    public Transaction(String transactionId, String accountId, double amount,
                       String location, LocalDateTime timestamp) {
        if (transactionId == null || accountId == null || location == null || timestamp == null) {
            throw new IllegalArgumentException("Transaction fields cannot be null.");
        }
        if (amount < 0) {
            throw new IllegalArgumentException("Amount cannot be negative.");
        }
        this.transactionId = transactionId;
        this.accountId = accountId;
        this.amount = amount;
        this.location = location;
        this.timestamp = timestamp;
    }

    public String getTransactionId() { return transactionId; }
    public String getAccountId() { return accountId; }
    public double getAmount() { return amount; }
    public String getLocation() { return location; }
    public LocalDateTime getTimestamp() { return timestamp; }

    @Override
    public String toString() {
        return "Transaction{id='" + transactionId + "', account='" + accountId
                + "', amount=" + amount + ", location='" + location
                + "', time=" + timestamp + "}";
    }
}
